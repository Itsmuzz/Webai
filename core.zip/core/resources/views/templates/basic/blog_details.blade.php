@extends('Template::layouts.frontend')
@section('content')
    <section class="blog-detials mt-120 mb-120">
        <div class="container">
            <div class="row gy-4">
                <div class="col-lg-8 col-xl-9">
                    <div class="blog-details">
                        <div class="blog-details__header">
                            <img class="blog-details__thumb" src="{{ frontendImage('blog', $blog?->data_values?->image, '1245x750') }}" alt="img">
                        </div>
                        <div class="blog-details__body">
                            <span class="blog-details__date">
                                <i class="fa-regular fa-clock"></i>
                                {{ showDateTime($blog->created_at, 'd M Y') }}
                            </span>
                            <h4 class="blog-details__title">
                                {{ __($blog?->data_values?->title ?? '') }}
                            </h4>
                            @php echo $blog->data_values->description @endphp
                        </div>
                    </div>
                    <div class="fb-comments" data-href="{{ url()->current() }}" data-numposts="5"></div>
                </div>
                <div class="col-lg-4 col-xl-3">
                    <aside class="blog-details-sidebar">
                        <div class="blog-details-sidebar-block">
                            <div class="blog-details-sidebar-block__header">
                                <h6 class="blog-details-sidebar-block__title">
                                    @lang('Recent Blogs')
                                </h6>
                            </div>
                            <div class="blog-details-sidebar-block__body">
                                <ul class="latest-blog">
                                    @foreach ($recentBlogs as $recentBlog)
                                        <li class="latest-blog-item">
                                            <img class="latest-blog-item__thumb" src="{{ frontendImage('blog', 'thumb_' . $recentBlog?->data_values?->image ?? '', '415x250') }}"
                                                 alt="">
                                            <div class="latest-blog-item__content">
                                                <h6 class="latest-blog-item__title">
                                                    <a href="{{ route('blog.details', $recentBlog->slug) }}">
                                                        {{ strLimit(__($recentBlog?->data_values?->title ?? ''), 50) }}
                                                    </a>
                                                </h6>
                                                <span class="badge badge--info latest-blog-item__date">
                                                    {{ showDateTime($recentBlog->created_at, 'd M Y') }}
                                                </span>
                                            </div>
                                        </li>
                                    @endforeach
                                </ul>
                            </div>
                        </div>
                        <div class="blog-details-sidebar-block">
                            <div class="blog-details-sidebar-block__header">
                                <h6 class="blog-details-sidebar-block__title">
                                    @lang('Share On'):
                                </h6>
                            </div>
                            <div class="blog-details-sidebar-block__body">
                                <ul class="social-list">
                                    <li class="social-list__item">
                                        <a class="social-list__link" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u={{ urlencode(url()->current()) }}">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                    <li class="social-list__item">
                                        <a class="social-list__link" target="_blank" href="https://twitter.com/intent/tweet?url={{ urlencode(url()->current()) }}&text={{ urlencode($blog->title) }}">
                                            <i class="fa-brands fa-x-twitter"></i>
                                        </a>
                                    </li>
                                    <li class="social-list__item">
                                        <a class="social-list__link" target="_blank" href="https://www.linkedin.com/shareArticle?mini=true&url={{ urlencode(url()->current()) }}&title={{ urlencode($blog->title) }}">
                                            <i class="fab fa-linkedin-in"></i>
                                        </a>
                                    </li>
                                    <li class="social-list__item">
                                        <a class="social-list__link" target="_blank" href="https://pinterest.com/pin/create/button/?url={{ urlencode(url()->current()) }}&media={{ urlencode(frontendImage('blog', 'thumb_' . $blog?->data_values?->image, '470x265')) }}&description={{ urlencode($blog?->data_values?->title ?? '') }}">
                                            <i class="fab fa-pinterest"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="blog-details-sidebar-block">
                            <div class="blog-details-sidebar-block__header">
                                <h6 class="blog-details-sidebar-block__title">
                                    @lang('Copy Link'):
                                </h6>
                            </div>
                            <div class="blog-details-sidebar-block__body">
                                <div class="input-group input--group input--group-copy">
                                    <input type="text" class="form-control form--control copy-input"
                                           value="{{ url()->current() }}">
                                    <button class="input-group-text copy-btn" type="button">
                                        <i class="las la-copy"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </aside>
                </div>
            </div>
        </div>
    </section>
@endsection
@push('fbComment')
    @php echo loadExtension('fb-comment') @endphp
@endpush
