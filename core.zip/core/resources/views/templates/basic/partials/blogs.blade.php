@php
    $delay = 300;
@endphp
@foreach ($blogs as $blog)
    <div class="col-xsm-6 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="{{ $delay }}">
        <div class="blog-card">
            <div class="blog-card__thumb">
                <img src="{{ frontendImage('blog', 'thumb_' . $blog?->data_values?->image ?? '', '415x250') }}" alt="img">
            </div>
            <div class="blog-card__content">
                <span class="blog-card__date badge badge--base">
                    {{ showDateTime($blog->created_at, 'd M Y') }}
                </span>
                <div class="blog-card__content-bottom">
                    <h6 class="blog-card__title">
                        <a href="{{ route('blog.details', $blog->slug) }}">{{ strLimit(__($blog?->data_values?->title ?? ''), 60) }}</a>
                    </h6>
                    <a class="blog-card__link" href="{{ route('blog.details', $blog->slug) }}">
                        <i class="las la-arrow-right"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    @php
        $delay += 100;
    @endphp
@endforeach
