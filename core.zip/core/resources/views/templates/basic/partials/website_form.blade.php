@php
    $websiteType = App\Models\WebsiteType::active()->get(['id', 'name']);
    $websitePages = App\Models\WebsitePage::active()->get(['id', 'name']);
    $websiteSections = App\Models\WebsiteSection::active()->get(['id', 'name']);
    $fontFamilies = fontFamilyList();
@endphp
<form id="gen-form" class="gen-form" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="600">
    @csrf
    <div class="gen-form-loader d-none">
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="sparkle">
            <defs>
                <linearGradient id="starGradient">
                    <stop offset="0%" stop-color="hsl(var(--base))" />
                    <stop offset="29.81%" stop-color="hsl(var(--base-two))" />
                    <stop offset="64.42%" stop-color="hsl(var(--base-three))" />
                    <stop offset="100%" stop-color="hsl(var(--base-four))" />
                </linearGradient>
            </defs>
            <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor" fill="currentColor"
                  d="M14.187 8.096L15 5.25L15.813 8.096C16.0231 8.83114 16.4171 9.50062 16.9577 10.0413C17.4984 10.5819 18.1679 10.9759 18.903 11.186L21.75 12L18.904 12.813C18.1689 13.0231 17.4994 13.4171 16.9587 13.9577C16.4181 14.4984 16.0241 15.1679 15.814 15.903L15 18.75L14.187 15.904C13.9769 15.1689 13.5829 14.4994 13.0423 13.9587C12.5016 13.4181 11.8321 13.0241 11.097 12.814L8.25 12L11.096 11.187C11.8311 10.9769 12.5006 10.5829 13.0413 10.0423C13.5819 9.50162 13.9759 8.83214 14.186 8.097L14.187 8.096Z">
            </path>
            <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor" fill="currentColor"
                  d="M6 14.25L5.741 15.285C5.59267 15.8785 5.28579 16.4206 4.85319 16.8532C4.42059 17.2858 3.87853 17.5927 3.285 17.741L2.25 18L3.285 18.259C3.87853 18.4073 4.42059 18.7142 4.85319 19.1468C5.28579 19.5794 5.59267 20.1215 5.741 20.715L6 21.75L6.259 20.715C6.40725 20.1216 6.71398 19.5796 7.14639 19.147C7.5788 18.7144 8.12065 18.4075 8.714 18.259L9.75 18L8.714 17.741C8.12065 17.5925 7.5788 17.2856 7.14639 16.853C6.71398 16.4204 6.40725 15.8784 6.259 15.285L6 14.25Z">
            </path>
            <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor" fill="currentColor"
                  d="M6.5 4L6.303 4.5915C6.24777 4.75718 6.15472 4.90774 6.03123 5.03123C5.90774 5.15472 5.75718 5.24777 5.5915 5.303L5 5.5L5.5915 5.697C5.75718 5.75223 5.90774 5.84528 6.03123 5.96877C6.15472 6.09226 6.24777 6.24282 6.303 6.4085L6.5 7L6.697 6.4085C6.75223 6.24282 6.84528 6.09226 6.96877 5.96877C7.09226 5.84528 7.24282 5.75223 7.4085 5.697L8 5.5L7.4085 5.303C7.24282 5.24777 7.09226 5.15472 6.96877 5.03123C6.84528 4.90774 6.75223 4.75718 6.697 4.5915L6.5 4Z">
            </path>
        </svg>
        <p class="gen-form-loader__text">@lang('Generating Your Website...')</p>
    </div>
    <div class="gen-form-wrapper">
        <div class="gen-form-sidebar">
            <div class="gen-form-sidebar__body">
                <div class="gen-form-block">
                    <div class="gen-form-block__header">
                        <h6 class="gen-form-block__title">@lang('Site Settings')</h6>
                    </div>
                    <div class="gen-form-block__body">
                        <div class="row g-2">
                            <div class="col-12">
                                <select class="form-select form--select select2-v2" name="website_type_id" data-label="Select Type">
                                    @foreach ($websiteType as $type)
                                        <option value="{{ $type->id }}">{{ __($type->name) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <select class="form-select form--select select2-v2" name="font_family" data-label="Select Font Family">
                                    @foreach ($fontFamilies as $font)
                                        <option value="{{ $font }}">{{ $font }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <div class="gen-form-field gen-form-field--color">
                                    <span class="gen-form-field__label">@lang('Select Color')</span>
                                    <div class="color-pickr">
                                        <div class="color-pickr__el"></div>
                                        <input class="color-pickr__input" type="text" name="color" value="#3b82f6">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gen-form-block">
                    <div class="gen-form-block__header">
                        <h6 class="gen-form-block__title">@lang('Site Pages')</h6>
                    </div>
                    <div class="gen-form-block__body">
                        <div class="gen-form-search">
                            <input class="form-control form-control--sm form--control" name="search" type="text" placeholder="Type to search" autocomplete="off">
                        </div>
                        <div class="row g-2 page-list-data">
                            @foreach ($websitePages as $page)
                                <div class="col-sm-6 single-page-item">
                                    <label class="custom-check" for="site-page-{{ $page->id }}" data-target="#page-block-{{ $page->id }}">
                                        <input class="custom-check__input visually-hidden" type="checkbox" name="website_page_id[]" value="{{ $page->id }}" id="site-page-{{ $page->id }}">
                                        <span class="custom-check__circle"></span>
                                        <span class="custom-check__label">{{ __($page->name) }}</span>
                                    </label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>
            </div>
            <div class="gen-form-sidebar__footer">
                <button class="w-100 btn btn--sm btn--gen generateBtn" type="submit">
                    <span class="btn__border"></span>
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" class="sparkle">
                        <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor"
                              fill="currentColor"
                              d="M14.187 8.096L15 5.25L15.813 8.096C16.0231 8.83114 16.4171 9.50062 16.9577 10.0413C17.4984 10.5819 18.1679 10.9759 18.903 11.186L21.75 12L18.904 12.813C18.1689 13.0231 17.4994 13.4171 16.9587 13.9577C16.4181 14.4984 16.0241 15.1679 15.814 15.903L15 18.75L14.187 15.904C13.9769 15.1689 13.5829 14.4994 13.0423 13.9587C12.5016 13.4181 11.8321 13.0241 11.097 12.814L8.25 12L11.096 11.187C11.8311 10.9769 12.5006 10.5829 13.0413 10.0423C13.5819 9.50162 13.9759 8.83214 14.186 8.097L14.187 8.096Z">
                        </path>
                        <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor"
                              fill="currentColor"
                              d="M6 14.25L5.741 15.285C5.59267 15.8785 5.28579 16.4206 4.85319 16.8532C4.42059 17.2858 3.87853 17.5927 3.285 17.741L2.25 18L3.285 18.259C3.87853 18.4073 4.42059 18.7142 4.85319 19.1468C5.28579 19.5794 5.59267 20.1215 5.741 20.715L6 21.75L6.259 20.715C6.40725 20.1216 6.71398 19.5796 7.14639 19.147C7.5788 18.7144 8.12065 18.4075 8.714 18.259L9.75 18L8.714 17.741C8.12065 17.5925 7.5788 17.2856 7.14639 16.853C6.71398 16.4204 6.40725 15.8784 6.259 15.285L6 14.25Z">
                        </path>
                        <path class="path" stroke-linejoin="round" stroke-linecap="round" stroke="currentColor"
                              fill="currentColor"
                              d="M6.5 4L6.303 4.5915C6.24777 4.75718 6.15472 4.90774 6.03123 5.03123C5.90774 5.15472 5.75718 5.24777 5.5915 5.303L5 5.5L5.5915 5.697C5.75718 5.75223 5.90774 5.84528 6.03123 5.96877C6.15472 6.09226 6.24777 6.24282 6.303 6.4085L6.5 7L6.697 6.4085C6.75223 6.24282 6.84528 6.09226 6.96877 5.96877C7.09226 5.84528 7.24282 5.75223 7.4085 5.697L8 5.5L7.4085 5.303C7.24282 5.24777 7.09226 5.15472 6.96877 5.03123C6.84528 4.90774 6.75223 4.75718 6.697 4.5915L6.5 4Z">
                        </path>
                    </svg>
                    <span class="btn__text">@lang('Generate')</span>
                    <span class="btn__spinner"></span>
                </button>
            </div>
        </div>
        <div class="gen-form-main" id="websiteResultArea">
            <div class="gen-form-card">
                <div class="gen-form-card__header">
                    <h6 class="gen-form-card__title">@lang('Sections')</h6>
                </div>
                <div class="gen-form-card__body">
                    @foreach ($websitePages as $page)
                        <div class="form-group d-none" id="page-block-{{ $page->id }}">
                            <select class="form-select form--select select2-v2" name="pages[{{ $page->id }}][]" data-label="Choose {{ __($page->name) }} Page Section" multiple>
                                @foreach ($websiteSections as $section)
                                    <option value="{{ $section->id }}">{{ __($section->name) }}</option>
                                @endforeach
                            </select>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="gen-form-empty">
                <div class="gen-form-empty__icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="lucide lucide-sliders-horizontal-icon lucide-sliders-horizontal">
                        <path d="M10 5H3" />
                        <path d="M12 19H3" />
                        <path d="M14 3v4" />
                        <path d="M16 17v4" />
                        <path d="M21 12h-9" />
                        <path d="M21 19h-5" />
                        <path d="M21 5h-7" />
                        <path d="M8 10v4" />
                        <path d="M8 12H3" />
                    </svg>
                </div>
                <div class="gen-form-empty__content">
                    <h6 class="gen-form-empty__title">
                        @lang('Customize Your Site')
                    </h6>
                    <p class="gen-form-empty__desc">
                        @lang('Please start by selecting your desired Select Type, Font Family, and Color from the options on the left.Once selected, choose the pages you need')
                    </p>
                </div>
            </div>
            <div class="gen-form-result d-none">
            </div>
        </div>
    </div>
</form>
