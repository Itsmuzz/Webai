@if (gs('socialite_credentials')->linkedin->status || gs('socialite_credentials')->facebook->status == Status::ENABLE || gs('socialite_credentials')->google->status == Status::ENABLE)
    <div class="social-auth">
        @if (gs('socialite_credentials')->google->status == Status::ENABLE)
            <a class="social-auth__btn" href="{{ route('user.social.login', 'google') }}">
                <img src="{{ asset(activeTemplate(true) . 'images/google.svg') }}" alt="">
                <span class="text">@lang('Google')</span>
            </a>
        @endif
        @if (gs('socialite_credentials')->facebook->status == Status::ENABLE)
            <a class="social-auth__btn" href="{{ route('user.social.login', 'facebook') }}">
                <img src="{{ asset(activeTemplate(true) . 'images/facebook.svg') }}" alt="">
                <span class="text">@lang('Facebook')</span>
            </a>
        @endif
        @if (gs('socialite_credentials')->linkedin->status == Status::ENABLE)
            <a class="social-auth__btn" href="{{ route('user.social.login', 'linkedin') }}">
                <img src="{{ asset(activeTemplate(true) . 'images/linkdin.svg') }}" alt="img">
                <span class="text">@lang('Linkedin')</span>
            </a>
        @endif
    </div>
    <div class="account-divider">
        <span>@lang('Or')</span>
    </div>
@endif
