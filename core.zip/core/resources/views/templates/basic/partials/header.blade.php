<header class="header" id="header">
    <div class="container container-lg">
        <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand order-1" href="{{ route('home') }}">
                <img src="{{ siteLogo() }}" alt="img">
            </a>
            <div class="offcanvas offcanvas-end navbar--offcanvas order-4 order-lg-2" tabindex="-1"
                 id="navbar-offcanvas">
                <div class="offcanvas-header d-lg-none">
                    <a class="navbar-brand logo" href="{{ route('home') }}">
                        <img src="{{ siteLogo() }}" alt="img">
                    </a>
                    <button type="button" class="btn btn--icon btn--close" data-bs-dismiss="offcanvas"></button>
                </div>
                <div class="offcanvas-body align-items-center">
                    <ul class="navbar-nav nav-menu mx-auto align-items-lg-center">
                        <li class="nav-item {{ menuActive('home') }}">
                            <a class="nav-link" aria-current="page" href="{{ route('home') }}">@lang('Home')</a>
                        </li>
                        @foreach ($pages as $k => $data)
                            <li class="nav-item @if ($data->slug == Request::segment(1)) active @endif">
                                <a class="nav-link" aria-current="page" href="{{ route('pages', $data->slug) }}">{{ __($data->name) }}</a>
                            </li>
                        @endforeach
                        <li class="nav-item {{ menuActive('pricing') }}">
                            <a class="nav-link" href="{{ route('pricing') }}">@lang('Pricing')</a>
                        </li>
                        <li class="nav-item {{ menuActive('blog') }}">
                            <a class="nav-link" href="{{ route('blog') }}">@lang('Blog')</a>
                        </li>
                        <li class="nav-item {{ menuActive('contact') }}">
                            <a class="nav-link" href="{{ route('contact') }}">@lang('Contact')</a>
                        </li>
                        @if (gs('multi_language'))
                            <li class="nav-item order-first order-lg-last">
                                @include('Template::partials.language')
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
            <button class="navbar-toggler order-3" type="button" data-bs-toggle="offcanvas"
                    data-bs-target="#navbar-offcanvas">
                <i class="las la-bars"></i>
            </button>
            @auth
                @include('Template::partials.auth_nav')
            @else
                <div class="navbar-guest-area order-2 order-lg-3 ms-auto ms-lg-0">
                    <a class="btn btn--base" href="{{ route('user.login') }}">
                        @lang('Login')
                    </a>
                </div>
            @endauth
        </nav>
    </div>
</header>
