@php
    $breadcrumbContent = getContent('breadcrumb.content', true);
@endphp
<section class="page-banner bg-img" data-background-image="{{ frontendImage('breadcrumb', $breadcrumbContent?->data_values?->image ?? '', '1920x320') }}">
    <div class="page-banner-bg">
        <div class="page-banner-bg__shape one"></div>
        <div class="page-banner-bg__shape two"></div>
        <div class="page-banner-bg__shape three"></div>
    </div>
    <div class="container">
        <h3 class="page-banner__title">{{ isset($customPageTitle) ? __($customPageTitle) : __($pageTitle) }}</h3>
        <ul class="breadcrumb custom--breadcrumb">
            <li class="breadcrumb-item">
                <a href="{{ route('home') }}"><i class="fas fa-home"></i>@lang('Home')</a>
            </li>
            <li class="breadcrumb-item active" aria-current="page">
                {{ isset($customPageTitle) ? __($customPageTitle) : __($pageTitle) }}
            </li>
        </ul>
    </div>
</section>
