 @php
     $language = App\Models\Language::all();
     $activeLanguage = App\Models\Language::where('code', session('lang'))->first();
 @endphp
 <div class="dropdown dropdown--lang">
     <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
         <span class="icon">
             <svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 16 16" fill="none"
                  preserveAspectRatio="xMidYMid meet" aria-hidden="true" role="img">
                 <path d="M1.5 8H14.5" stroke="currentColor" stroke-width="1.21" stroke-linecap="round"
                       stroke-linejoin="round"></path>
                 <path
                       d="M8 14.5C11.5899 14.5 14.5 11.5899 14.5 8C14.5 4.41015 11.5899 1.5 8 1.5C4.41015 1.5 1.5 4.41015 1.5 8C1.5 11.5899 4.41015 14.5 8 14.5Z"
                       stroke="currentColor" stroke-width="1.21" stroke-linecap="round" stroke-linejoin="round"></path>
                 <path
                       d="M10.7083 8C10.7083 12.3333 7.99996 14.5 7.99996 14.5C7.99996 14.5 5.29163 12.3333 5.29163 8C5.29163 3.66667 7.99996 1.5 7.99996 1.5C7.99996 1.5 10.7083 3.66667 10.7083 8Z"
                       stroke="currentColor" stroke-width="1.21" stroke-linecap="round" stroke-linejoin="round"></path>
             </svg>
         </span>
         <span class="text">{{ strtoupper($activeLanguage->code) }}</span>
     </button>
     <div class="dropdown-menu">
         @foreach ($language as $item)
             <a class="dropdown-item" href="{{ route('home') }}/change/{{ $item->code }}">
                 <img class="lang-flag" src="{{ getImage(getFilePath('language') . '/' . $item->image ?? '', getFileSize('language')) }}" alt="usa">
                 <span class="lang-text">{{ $item->name }}</span>
             </a>
         @endforeach
     </div>
 </div>
