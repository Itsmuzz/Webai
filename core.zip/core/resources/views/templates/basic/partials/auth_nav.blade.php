<div class="navbar-auth-area order-2 order-lg-3 ms-auto ms-lg-0">
    <div class="dropdown dropdown--profile">
        <button class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="{{ getImage(getFilePath('userProfile') . '/' . auth()->user()?->image, getFileSize('userProfile')) }}" alt="img" />
        </button>
        <div class="dropdown-menu dropdown-menu-end">
            <div class="dropdown-menu__header">
                <div class="dropdown-info">
                    <p class="dropdown-info__name">{{ auth()->user()->fullname }}</p>
                    <span class="dropdown-info__balance">
                        <span class="label">@lang('Websites Remaining'):</span>
                        <span class="value">{{ auth()->user()?->website_limit ?? 0 }}</span>
                    </span>
                </div>
            </div>
            <div class="dropdown-menu__body">
                <a class="dropdown-item" href="{{ route('pricing') }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-crown-icon lucide-crown">
                        <path
                              d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z" />
                        <path d="M5 21h14" />
                    </svg>
                    <span class="text">@lang('Upgrade Plans')</span>
                </a>
                <a class="dropdown-item" href="{{ route('user.website.history') }}">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" class="injected-svg" color="currentColor">
                        <path d="M16 12H12L12 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M18.8475 4.17041C19.0217 4.3242 19.1911 4.48354 19.3555 4.648C19.5199 4.81246 19.6791 4.98203 19.8328 5.15629M15 2C15.4821 2.14255 15.9548 2.32634 16.4134 2.54664M21.4375 7.55457C21.6647 8.02313 21.8539 8.50663 22 9" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                    </svg>
                    <span class="text">@lang('History')</span>
                </a>
                <a class="dropdown-item" href="{{ route('user.deposit.history') }}">
                    <svg
                         width="24"
                         height="24"
                         viewBox="0 0 24 24"
                         fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path
                              d="M11.0065 21H9.60546C6.02021 21 4.22759 21 3.11379 19.865C2 18.7301 2 16.9034 2 13.25C2 9.59661 2 7.76992 3.11379 6.63496C4.22759 5.5 6.02021 5.5 9.60546 5.5H13.4082C16.9934 5.5 18.7861 5.5 19.8999 6.63496C20.7568 7.50819 20.9544 8.7909 21 11"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"></path>
                        <path
                              d="M18.85 18.85L17.5 17.95V15.7M13 17.5C13 19.9853 15.0147 22 17.5 22C19.9853 22 22 19.9853 22 17.5C22 15.0147 19.9853 13 17.5 13C15.0147 13 13 15.0147 13 17.5Z"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"></path>
                        <path
                              d="M16 5.5L15.9007 5.19094C15.4056 3.65089 15.1581 2.88087 14.5689 2.44043C13.9796 2 13.197 2 11.6316 2H11.3684C9.80304 2 9.02036 2 8.43111 2.44043C7.84186 2.88087 7.59436 3.65089 7.09934 5.19094L7 5.5"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"></path>
                    </svg>
                    <span class="text">@lang('Payment Log')</span>
                </a>


                <a class="dropdown-item" href="{{ route('user.subscription.log') }}">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" x="0" y="0" viewBox="0 0 64 64" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M15 49.5H8A4.505 4.505 0 0 1 3.5 45V13c0-2.481 2.019-4.5 4.5-4.5h7a1.5 1.5 0 1 1 0 3H8c-.827 0-1.5.673-1.5 1.5v32c0 .827.673 1.5 1.5 1.5h7a1.5 1.5 0 1 1 0 3zM53 38.1a1.5 1.5 0 0 1-1.5-1.5V13c0-.827-.673-1.5-1.5-1.5h-7a1.5 1.5 0 1 1 0-3h7c2.481 0 4.5 2.019 4.5 4.5v23.6a1.5 1.5 0 0 1-1.5 1.5z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M30 54.5H18a4.505 4.505 0 0 1-4.5-4.5V8c0-2.481 2.019-4.5 4.5-4.5h22c2.481 0 4.5 2.019 4.5 4.5v27.69a1.5 1.5 0 1 1-3 0V8c0-.827-.673-1.5-1.5-1.5H18c-.827 0-1.5.673-1.5 1.5v42c0 .827.673 1.5 1.5 1.5h12a1.5 1.5 0 1 1 0 3z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M36 23.5H22a1.5 1.5 0 0 1-1.5-1.5V12a1.5 1.5 0 0 1 2.4-1.2l2.959 2.22 2.079-2.08a1.5 1.5 0 0 1 2.122-.001l2.08 2.08 2.96-2.22a1.5 1.5 0 0 1 2.4 1.2v10.001a1.5 1.5 0 0 1-1.5 1.5zm-12.5-3h11V15l-1.6 1.2a1.5 1.5 0 0 1-1.96-.14L29 14.122l-1.939 1.94a1.5 1.5 0 0 1-1.96.14L23.5 15v5.5zM29 45.338c-1.553 0-2.968-.914-3.521-2.276a1.5 1.5 0 1 1 2.779-1.129c.096.235.408.405.742.405.61 0 1.125-.394 1.125-.86v-.117c0-.477-1.027-.819-1.381-.883-1.431-.238-3.869-1.318-3.869-3.84v-.115c0-2.129 1.85-3.861 4.125-3.861 1.553 0 2.968.914 3.521 2.276a1.5 1.5 0 1 1-2.779 1.129c-.096-.235-.408-.405-.742-.405-.61 0-1.125.394-1.125.86v.117c0 .477 1.027.819 1.381.883 1.431.238 3.869 1.318 3.869 3.84v.115c0 2.129-1.85 3.861-4.125 3.861z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M29 35.662a1.5 1.5 0 0 1-1.5-1.5V32a1.5 1.5 0 1 1 3 0v2.162a1.5 1.5 0 0 1-1.5 1.5zM29 47.5a1.5 1.5 0 0 1-1.5-1.5v-2.162a1.5 1.5 0 1 1 3 0V46a1.5 1.5 0 0 1-1.5 1.5zM47 60.5c-7.444 0-13.5-6.056-13.5-13.5S39.556 33.5 47 33.5 60.5 39.556 60.5 47 54.444 60.5 47 60.5zm0-24c-5.79 0-10.5 4.71-10.5 10.5S41.21 57.5 47 57.5 57.5 52.79 57.5 47 52.79 36.5 47 36.5z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M45.25 52.5a1.5 1.5 0 0 1-1.06-.439l-4.5-4.5a1.5 1.5 0 1 1 2.12-2.121l3.44 3.439 6.94-6.94a1.5 1.5 0 1 1 2.12 2.121l-8 8.001a1.5 1.5 0 0 1-1.06.44z" fill="currentColor" opacity="1" data-original="#000000" class=""></path></g></svg>
                    <span class="text">@lang('Subscription Log')</span>
                </a>


                <a class="dropdown-item" href="{{ route('user.transactions') }}">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 64 64" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M14 16a2 2 0 0 1 2 2h2a4 4 0 0 0-3-3.858V12h-2v2.142A3.992 3.992 0 0 0 14 22a2 2 0 1 1-2 2h-2a4 4 0 0 0 3 3.858V30h2v-2.142A3.992 3.992 0 0 0 14 20a2 2 0 0 1 0-4ZM50 38a2 2 0 0 1 2 2h2a4 4 0 0 0-3-3.858V34h-2v2.142A3.992 3.992 0 0 0 50 44a2 2 0 1 1-2 2h-2a4 4 0 0 0 3 3.858V52h2v-2.142A3.992 3.992 0 0 0 50 42a2 2 0 0 1 0-4Z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M50 30a12.7 12.7 0 0 0-1 .051V24h2v3a1 1 0 0 0 1.651.759l7-6a1 1 0 0 0 0-1.518l-7-6A1 1 0 0 0 51 15v3h-2V7a6.006 6.006 0 0 0-6-6H21a6.006 6.006 0 0 0-6 6v1.051A12.7 12.7 0 0 0 14 8a13 13 0 0 0 0 26 12.7 12.7 0 0 0 1-.051V41h-2v-3a1 1 0 0 0-1.651-.759l-7 6a1 1 0 0 0 0 1.518l7 6A1 1 0 0 0 13 50v-3h2v10a6.006 6.006 0 0 0 6 6h22a6.006 6.006 0 0 0 6-6v-1.051A12.7 12.7 0 0 0 50 56a13 13 0 0 0 0-26Zm2-10a1 1 0 0 0 1-1v-1.826L57.463 21 53 24.826V23a1 1 0 0 0-1-1H35v-2ZM40.586 3l-2 2H25.414l-2-2ZM3 21a11 11 0 1 1 11 11A11.013 11.013 0 0 1 3 21Zm9 24a1 1 0 0 0-1 1v1.826L6.537 44 11 40.174V42a1 1 0 0 0 1 1h17v2Zm27 16H25v-1a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1Zm8-4a4 4 0 0 1-4 4h-2v-1a3 3 0 0 0-3-3H26a3 3 0 0 0-3 3v1h-2a4 4 0 0 1-4-4V47h13a1 1 0 0 0 1-1v-4a1 1 0 0 0-1-1H17v-7.363a12.985 12.985 0 0 0 0-25.274V7a3.992 3.992 0 0 1 3.624-3.962l3.669 3.669A1 1 0 0 0 25 7h14a1 1 0 0 0 .707-.293l3.669-3.669A3.992 3.992 0 0 1 47 7v11H34a1 1 0 0 0-1 1v4a1 1 0 0 0 1 1h13v6.363a12.985 12.985 0 0 0 0 25.274Zm3-3a11 11 0 1 1 11-11 11.013 11.013 0 0 1-11 11Z" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M28 14h12v2H28zM24 49h12v2H24zM34 10h8v2h-8zM30 52.857h8v2h-8z" fill="currentColor" opacity="1" data-original="#000000" class=""></path></g></svg>
                    <span class="text">@lang('Transactions')</span>
                </a>


                <a class="dropdown-item" href="{{ route('ticket.index') }}">
                    <svg
                         xmlns="http://www.w3.org/2000/svg"
                         width="24"
                         height="24"
                         viewBox="0 0 24 24"
                         fill="none"
                         class="injected-svg"
                         role="img"
                         color="currentColor">
                        <path
                              d="M2 9.5V6C2 4.89543 2.89543 4 4 4H20C21.1046 4 22 4.89543 22 6V9.5C20.6193 9.5 19.5 10.6193 19.5 12C19.5 13.3807 20.6193 14.5 22 14.5V18C22 19.1046 21.1046 20 20 20H4C2.89543 20 2 19.1046 2 18V14.5C3.38071 14.5 4.5 13.3807 4.5 12C4.5 10.6193 3.38071 9.5 2 9.5Z"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round"></path>
                    </svg>
                    <span class="text">@lang('Support Tickets')</span>
                </a>
                <a class="dropdown-item" href="{{ route('user.profile.setting') }}">
                    <svg
                         width="24"
                         height="24"
                         viewBox="0 0 24 24"
                         fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path
                              d="M15 9C15 7.34315 13.6569 6 12 6C10.3431 6 9 7.34315 9 9C9 10.6569 10.3431 12 12 12C13.6569 12 15 10.6569 15 9Z"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                              d="M22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22C17.5228 22 22 17.5228 22 12Z"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                              d="M17 17C17 14.2386 14.7614 12 12 12C9.23858 12 7 14.2386 7 17"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                    </svg>
                    <span class="text">@lang('Profile Setting')</span>
                </a>
                <a class="dropdown-item" href="{{ route('user.change.password') }}">
                    <svg
                         width="24"
                         height="24"
                         viewBox="0 0 24 24"
                         fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path
                              d="M4.26781 18.8447C4.49269 20.515 5.87613 21.8235 7.55966 21.9009C8.97627 21.966 10.4153 22 12 22C13.5847 22 15.0237 21.966 16.4403 21.9009C18.1239 21.8235 19.5073 20.515 19.7322 18.8447C19.879 17.7547 20 16.6376 20 15.5C20 14.3624 19.879 13.2453 19.7322 12.1553C19.5073 10.485 18.1239 9.17649 16.4403 9.09909C15.0237 9.03397 13.5847 9 12 9C10.4153 9 8.97627 9.03397 7.55966 9.09909C5.87613 9.17649 4.49269 10.485 4.26781 12.1553C4.12105 13.2453 4 14.3624 4 15.5C4 16.6376 4.12105 17.7547 4.26781 18.8447Z"
                              stroke="currentColor"
                              stroke-width="2" />
                        <path
                              d="M7.5 9V6.5C7.5 4.01472 9.51472 2 12 2C14.4853 2 16.5 4.01472 16.5 6.5V9"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                              d="M16 15.49V15.5"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                              d="M12 15.49V15.5"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                        <path
                              d="M8 15.49V15.5"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                    </svg>
                    <span class="text">@lang('Change Password')</span>
                </a>



                <a class="dropdown-item" href="{{ route('user.referrals') }}">
                    <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="24" height="24" x="0" y="0" viewBox="0 0 512 512.001" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="m220.77 376.727-47.067 47.066c-23.57 23.57-61.922 23.578-85.504 0-23.566-23.57-23.558-61.922.012-85.492l94.504-94.504c21.84-21.84 56.379-23.453 80.078-4.817a60.585 60.585 0 0 1 5.414 4.81c10.496 10.491 26.77 10.663 37.047.382l29.617-29.617a131.286 131.286 0 0 0-16.824-20.61c-8.926-8.922-18.824-16.293-29.371-22.093-41.266-22.762-92.301-21.625-132.602 3.406a131.002 131.002 0 0 0-23.554 18.699l-94.153 94.152c-51.152 51.153-51.152 134.38-.008 185.528 51.157 51.152 134.38 51.152 185.536 0l84.699-84.7c-29.586 3.915-60.04-.148-87.824-12.21zm0 0" fill="currentColor" opacity="1" data-original="#000000" class=""></path><path d="M473.637 38.36c-51.149-51.15-134.371-51.15-185.528.007l-84.691 84.692c29.586-3.918 60.039.144 87.824 12.21l47.07-47.07c23.57-23.57 61.915-23.57 85.485 0 23.578 23.578 23.578 61.922.008 85.492l-94.516 94.516c-21.598 21.598-55.875 23.09-79.547 4.543a59.29 59.29 0 0 1-5.566-4.926c-10.32-10.32-27.106-10.312-37.426.008l-29.617 29.617a132.205 132.205 0 0 0 16.824 20.59 130.937 130.937 0 0 0 29.594 22.227c41.492 22.777 92.785 21.445 133.113-3.98a130.975 130.975 0 0 0 22.816-18.24l94.157-94.151c51.152-51.157 51.152-134.38 0-185.536zm0 0" fill="currentColor" opacity="1" data-original="#000000" class=""></path></g></svg>
                    <span class="text">@lang('Referrals')</span>
                </a>



                <a class="dropdown-item logout" href="{{ route('user.logout') }}">
                    <svg
                         width="24"
                         height="24"
                         viewBox="0 0 24 24"
                         fill="none"
                         xmlns="http://www.w3.org/2000/svg">
                        <path
                              d="M15 17.625C14.9264 19.4769 13.3831 21.0494 11.3156 20.9988C10.8346 20.987 10.2401 20.8194 9.05112 20.484C6.18961 19.6768 3.70555 18.3203 3.10956 15.2815C3 14.723 3 14.0944 3 12.8373V11.1627C3 9.90561 3 9.27705 3.10956 8.71846C3.70555 5.67965 6.18961 4.32316 9.05112 3.51603C10.2401 3.18064 10.8346 3.01295 11.3156 3.00119C13.3831 2.95061 14.9264 4.52307 15 6.37501"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round" />
                        <path
                              d="M21 12H10M21 12C21 11.2998 19.0057 9.99153 18.5 9.5M21 12C21 12.7002 19.0057 14.0085 18.5 14.5"
                              stroke="currentColor"
                              stroke-width="2"
                              stroke-linecap="round"
                              stroke-linejoin="round" />
                    </svg>
                    <span class="text">@lang('Logout')</span>
                </a>
            </div>
        </div>
    </div>
</div>
