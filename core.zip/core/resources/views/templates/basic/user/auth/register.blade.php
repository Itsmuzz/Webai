@extends('Template::layouts.frontend')
@section('content')
    @if (gs('registration'))
        @php
            $registrationContent = getContent('register.content', true);
            $registrationElement = getContent('register.element', orderById: true);
            $bannerElement = getContent('banner.element', orderById: true);
        @endphp
        <section class="account">
            <div class="account-content">
                <div class="account-header">
                    <p class="account-info">
                        @lang('Already have an account?')
                        <a href="{{ route('user.login') }}">
                            @lang('Login Now')
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                 class="lucide lucide-arrow-up-right-icon lucide-arrow-up-right">
                                <path d="M7 7h10v10" />
                                <path d="M7 17 17 7" />
                            </svg>
                        </a>
                    </p>
                    <a class="account-logo" href="{{ route('home') }}">
                        <img src="{{ siteLogo() }}" alt="img">
                    </a>
                    <div class="account-heading">
                        <h4 class="account-heading__title">{{ __($registrationContent?->data_values?->form_heading ?? '') }}</h4>
                        <p class="account-heading__subtitle">{{ __($registrationContent?->data_values?->form_subheading ?? '') }}</p>
                    </div>
                </div>

                <div class="account-body">
                    @include('Template::partials.social_login')

                    <form action="{{ route('user.register') }}" method="POST" class="account-form verify-gcaptcha">
                        @csrf
                        <div class="row">
                            @if (session()->get('reference') != null)
                                <div class="col-md-12">
                                    <div class="form--group">
                                        <label for="referenceBy" class="form--label">@lang('Reference by')</label>
                                        <input type="text" name="referBy" id="referenceBy" class="form--control form-control" value="{{ session()->get('reference') }}" readonly>
                                    </div>
                                </div>
                            @endif
                            <div class="col-sm-6">
                                <div class="form--group">
                                    <label class="form--label">@lang('First Name')</label>
                                    <input type="text" class="form-control form--control" name="firstname" value="{{ old('firstname') }}" required>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form--group">
                                    <label class="form--label">@lang('Last Name')</label>
                                    <input type="text" class="form-control form--control" name="lastname" value="{{ old('lastname') }}" required>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form--group">
                                    <label class="form--label">@lang('Email Address')</label>
                                    <input type="email" class="form-control form--control checkUser" name="email" value="{{ old('email') }}" required>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form--group">
                                    <label class="form--label">@lang('Password')</label>
                                    <div class="input-group input--group input--group-password">
                                        <input class="form-control form--control @if (gs('secure_password')) secure-password @endif" name="password" type="password" required>
                                        <span class="input-group-text input-group-btn">
                                            <i class="far fa-eye-slash"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form--group">
                                    <label class="form--label">@lang('Confirm Password')</label>
                                    <div class="input-group input--group input--group-password">
                                        <input class="form-control form--control" name="password_confirmation" type="password" required>
                                        <span class="input-group-text input-group-btn">
                                            <i class="far fa-eye-slash"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <x-captcha label="form--label" class="true" />
                            </div>

                            @if (gs('agree'))
                                @php
                                    $policyPages = getContent('policy_pages.element', false, orderById: true);
                                @endphp
                                <div class="col-sm-12">
                                    <div class="form--check gradient form--group">
                                        <input type="checkbox" id="agree" @checked(old('agree')) name="agree" class="form-check-input" required>
                                        <label for="agree" class="form-check-label">
                                            @lang('I agree with')
                                            @foreach ($policyPages as $policy)
                                                <a href="{{ route('policy.pages', $policy->slug) }}" class="fs-14 ms-1" target="_blank">{{ __($policy->data_values->title) }}</a>
                                                @if (!$loop->last)
                                                    ,
                                                @endif
                                            @endforeach
                                        </label>
                                    </div>
                                </div>
                            @endif
                        </div>
                        <button class="w-100 btn btn--base mt-4" type="submit">
                            @lang('Submit')
                        </button>
                    </form>
                </div>
            </div>
            <div class="account-thumb bg-img" data-background-image="{{ frontendImage('register', $registrationContent?->data_values?->image ?? '', '960x945') }}">
                <div class="account-thumb__body">
                    <p class="account-thumb__tagline">
                        {{ __($registrationContent?->data_values?->heading ?? '') }}
                    </p>
                    <h2 class="account-thumb__title">
                        {{ __($registrationContent?->data_values?->subheading ?? '') }}
                    </h2>
                    <ul class="account-thumb-info">
                        @foreach ($registrationElement as $register)
                            <li class="account-thumb-info__item">{{ __($register?->data_values?->title ?? '') }}</li>
                        @endforeach
                    </ul>
                </div>
                <div class="account-thumb__footer">
                    <div class="account-slider account-slider-one">
                        @foreach ($bannerElement as $banner)
                            <div class="banner-slider__slide">
                                <div class="banner-slider__item">
                                    <img src="{{ frontendImage('banner', $banner?->data_values?->image ?? '', '20x20') }}" alt="img">
                                    {{ __($banner?->data_values?->title ?? '') }}
                                </div>
                            </div>
                        @endforeach
                    </div>
                    <div class="account-slider account-slider-two" dir="rtl">
                        @foreach ($bannerElement as $banner)
                            <div class="banner-slider__slide">
                                <div class="banner-slider__item">
                                    <img src="{{ frontendImage('banner', $banner?->data_values?->image ?? '', '20x20') }}" alt="img">
                                    {{ __($banner?->data_values?->title ?? '') }}
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </section>

        <div class="modal custom--modal fade" id="existModalCenter" tabindex="-1" role="dialog" aria-labelledby="existModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="existModalLongTitle">@lang('You are with us')</h5>
                        <button type="button" class="btn btn--close" data-bs-dismiss="modal" aria-label="Close">
                        </button>
                    </div>
                    <div class="modal-body">
                        <p class="text-center">@lang('You already have an account please Login ')</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--danger btn--sm" data-bs-dismiss="modal">@lang('Close')</button>
                        <a href="{{ route('user.login') }}" class="btn btn--base btn--sm">@lang('Login')</a>
                    </div>
                </div>
            </div>
        </div>
    @else
        @include('Template::partials.registration_disabled')
    @endif
@endsection
@if (gs('registration'))

    @push('style')
        <style>
            .social-login-btn {
                border: 1px solid #cbc4c4;
            }
        </style>
    @endpush

    @if (gs('secure_password'))
        @push('script-lib')
            <script src="{{ asset('assets/global/js/secure_password.js') }}"></script>
        @endpush
    @endif

    @push('script')
        <script>
            "use strict";
            (function($) {

                $('.checkUser').on('focusout', function(e) {
                    var url = '{{ route('user.checkUser') }}';
                    var value = $(this).val();
                    var token = '{{ csrf_token() }}';

                    var data = {
                        email: value,
                        _token: token
                    }

                    $.post(url, data, function(response) {
                        if (response.data != false) {
                            $('#existModalCenter').modal('show');
                        }
                    });
                });
            })(jQuery);
        </script>
    @endpush

@endif
