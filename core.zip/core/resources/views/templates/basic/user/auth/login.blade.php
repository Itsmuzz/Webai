@extends('Template::layouts.frontend')

@section('content')
    @php
        $loginContent = getContent('login.content', true);
        $loginElement = getContent('login.element', orderById: true);
        $bannerElement = getContent('banner.element', orderById: true);
    @endphp
    <section class="account">
        <div class="account-content">
            <div class="account-header">
                @if (gs('registration'))
                    <p class="account-info"> <a href="{{ route('user.register') }}"></a></p>
                    <p class="account-info">
                        @lang('Don\'t have any account?')
                        <a href="{{ route('user.register') }}">
                            @lang('Register Now')
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                 class="lucide lucide-arrow-up-right-icon lucide-arrow-up-right">
                                <path d="M7 7h10v10" />
                                <path d="M7 17 17 7" />
                            </svg>
                        </a>
                    </p>
                @endif
                <a class="account-logo" href="{{ route('home') }}">
                    <img src="{{ siteLogo() }}" alt="">
                </a>
                <div class="account-heading">
                    <h4 class="account-heading__title"> {{ __($loginContent?->data_values?->form_heading ?? '') }}</h4>
                    <p class="account-heading__subtitle">
                        {{ __($loginContent?->data_values?->form_subheading ?? '') }}
                    </p>
                </div>
            </div>

            <div class="account-body">
                @include('Template::partials.social_login')

                <form action="{{ route('user.login') }}" method="POST" class="account-form verify-gcaptcha">
                    @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form--group">
                                <label class="form--label">@lang('Username or Email')</label>
                                <input class="form-control form--control" name="username" value="{{ old('username') }}" type="text" required>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form--group">
                                <label class="form--label">@lang('Password')</label>
                                <div class="input-group input--group input--group-password">
                                    <input class="form-control form--control" type="password" name="password" autocomplete="off" required>
                                    <span class="input-group-text input-group-btn">
                                        <i class="far fa-eye-slash"></i>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="account-form__extra">
                                <div class="form--check">
                                    <input class="form-check-input" type="checkbox" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                    <label class="form-check-label" for="remember">@lang('Remember Me')</label>
                                </div>
                                <a href="{{ route('user.password.request') }}" class="account-form__forgot-link">@lang('Forgot Password?')</a>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <x-captcha label="form--label" class="true" />
                        </div>
                    </div>
                    <button class="w-100 btn btn--base mt-4" type="submit">
                        @lang('Submit')
                    </button>
                </form>
            </div>
        </div>
        <div class="account-thumb bg-img" data-background-image="{{ frontendImage('login', $loginContent?->data_values?->image ?? '', '960x945') }}">
            <div class="account-thumb__body">
                <p class="account-thumb__tagline">
                    {{ __($loginContent?->data_values?->heading ?? '') }}
                </p>
                <h2 class="account-thumb__title">
                    {{ __($loginContent?->data_values?->subheading ?? '') }}
                </h2>
                <ul class="account-thumb-info">
                    @foreach ($loginElement as $login)
                        <li class="account-thumb-info__item">{{ __($login?->data_values?->title ?? '') }}</li>
                    @endforeach
                </ul>
            </div>
            <div class="account-thumb__footer">
                <div class="account-slider account-slider-one">
                    @foreach ($bannerElement as $banner)
                        <div class="banner-slider__slide">
                            <div class="banner-slider__item">
                                <img src="{{ frontendImage('banner', $banner?->data_values?->image ?? '', '20x20') }}" alt="img">
                                {{ __($banner?->data_values?->title ?? '') }}
                            </div>
                        </div>
                    @endforeach
                </div>
                <div class="account-slider account-slider-two" dir="rtl">
                    @foreach ($bannerElement as $banner)
                        <div class="banner-slider__slide">
                            <div class="banner-slider__item">
                                <img src="{{ frontendImage('banner', $banner?->data_values?->image ?? '', '20x20') }}" alt="img">
                                {{ __($banner?->data_values?->title ?? '') }}
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    </section>
@endsection
