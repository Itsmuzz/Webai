<div class="gen-form-result__icon">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24"
         fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <circle cx="12" cy="12" r="10"></circle>
        <path d="M12 6v6l4 2"></path>
    </svg>
</div>

<div class="gen-form-result__content">
    <h6 class="gen-form-result__title">
        @lang('Website Generation Started')
    </h6>

    <p class="gen-form-result__desc">
        @lang('Your request has been successfully submitted. The website is being generated in the background using our automated system.')
        <br>
        <strong>@lang('This may take a few minutes.')</strong>
        <br><br>
        @lang('You can track the progress, view logs, and download your website once it is ready from the History page.')
    </p>

    <div class="gen-form-result__btns">
        <a href="{{ route('user.website.history') }}" class="btn btn--base btn--xsm">
            <span class="icon me-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M3 3v18h18"></path>
                    <path d="M7 14l3-3 4 4 5-6"></path>
                </svg>
            </span>
            @lang('View History')
        </a>

        <a href="{{ route('home') }}" class="btn btn-soft--base btn--xsm">
            <span class="icon me-1">
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M12 5v14"></path>
                    <path d="M5 12h14"></path>
                </svg>
            </span>
            @lang('Create Another Website')
        </a>
    </div>
</div>
    