@extends('Template::layouts.master')

@section('content')
    <section class="my-120">
        <div class="container">
            <div class="row justify-content-center gy-4">
                @forelse ($generatedWebsites as $website)
                    <div class=" col-sm-6 col-lg-4">
                        <div class="project-card2">
                            <div class="project-card2__header">
                                <div class="project-card2__thumb">
                                    <img src="{{ getImage(getFilePath('websites') . '/' . $website?->folder_name . '/screenshot.png', demo: true) }}" alt="img">
                                </div>
                            </div>
                            <div class="project-card2__body">
                                <h6 class="project-card2__title">
                                    {{ __($website?->websiteType?->name ?? '') }}
                                </h6>
                                <ul class="project-card2-meta mb-2">
                                    <li class="project-card2-meta__item">
                                        <span class="label">@lang('Total Pages')</span>
                                        <span class="value">{{ getAmount($website->total_page) }}</span>
                                    </li>
                                    <li class="project-card2-meta__item">
                                        <span class="label">@lang('Status')</span>
                                        @if ($website->status == Status::WEBSITE_GENERATED)
                                            <span class="badge badge--base">@lang('Generated')</span>
                                        @else
                                            <span class="badge badge--warning">@lang('Pending')</span>
                                        @endif
                                    </li>
                                    <li class="project-card2-meta__item">
                                        <span class="label">@lang('Generated At')</span>
                                        <span class="value">{{ showDateTime($website->created_at, 'd M, Y h:i A') }}</span>
                                    </li>
                                </ul>
                                <div class="project-card2__progress">
                                    <span class="label">@lang('Website Completed')</span>
                                    <div class="wrapper">
                                        <div class="progress" role="progressbar" aria-label="{{ $website->status == Status::WEBSITE_GENERATED ? 'Success' : 'Default' }} striped example" aria-valuenow="10" aria-valuemin="0" aria-valuemax="100">
                                            <div class="progress-bar progress-bar-striped {{ $website->status == Status::WEBSITE_GENERATED ? 'bg-success' : '' }}" style="width: {{ getAmount($website->complete_percentage) }}%"></div>
                                        </div>
                                        <span class="value">{{ getAmount($website->complete_percentage) }}%</span>
                                    </div>
                                </div>
                            </div>
                            <div class="project-card2__footer">
                                <div class="project-card2__btns">
                                    @if ($website->status == Status::WEBSITE_GENERATED)
                                        <a class="btn btn--sm btn-outline--base btn--preview" href="{{ route('user.website.preview', $website->folder_name) }}" target="_blank">
                                            @lang('Preview')
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                 class="lucide lucide-arrow-up-right-icon lucide-arrow-up-right">
                                                <path d="M7 7h10v10" />
                                                <path d="M7 17 17 7" />
                                            </svg>
                                        </a>
                                        <a class="btn btn--sm btn--base btn--download" href="{{ route('user.website.download', encrypt($website->id)) }}">
                                            @lang('Download')
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                 class="lucide lucide-download-icon lucide-download">
                                                <path d="M12 15V3" />
                                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                                <path d="m7 10 5 5 5-5" />
                                            </svg>
                                        </a>
                                    @else
                                        <button class="btn btn--sm btn-outline--base btn--preview" type="button" disabled>
                                            @lang('Preview')
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                 class="lucide lucide-arrow-up-right-icon lucide-arrow-up-right">
                                                <path d="M7 7h10v10" />
                                                <path d="M7 17 17 7" />
                                            </svg>
                                        </button>
                                        <button class="btn btn--sm btn--base btn--download" type="button" disabled>
                                            @lang('Download')
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                                 class="lucide lucide-download-icon lucide-download">
                                                <path d="M12 15V3" />
                                                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
                                                <path d="m7 10 5 5 5-5" />
                                            </svg>
                                        </button>
                                    @endif

                                </div>
                            </div>
                        </div>
                    </div>
                @empty
                    <div class="col-lg-6">
                        <div class="empty__data">
                            <div class="empty__data__inner">
                                <svg xmlns="http://www.w3.org/2000/svg" width="52" height="52" viewBox="0 0 24 24" fill="none"
                                     class="injected-svg"
                                     data-src="https://cdn.hugeicons.com/icons/file-not-found-stroke-standard.svg?v=1.0.1"
                                     xmlns:xlink="http://www.w3.org/1999/xlink" role="img" color="#ffffff">
                                    <path d="M15 15C13.8954 15 13 15.8954 13 17V22" stroke="#ffffff" stroke-width="1.5"
                                          stroke-linejoin="round"></path>
                                    <path d="M2 2L22 22" stroke="#ffffff" stroke-width="1.5" stroke-linecap="round"
                                          stroke-linejoin="round"></path>
                                    <path
                                          d="M6.02496 2H17.9969C19.1014 2 19.9969 2.89543 19.9969 4V15.0145L19.5052 15.5052M4.02496 3.99688L4 19.9984C3.99828 21.1042 4.89421 22.0015 6 22.0015H12.9955L17.5031 17.5031"
                                          stroke="#ffffff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                                <h6 class="mt-2">@lang('No Websites Found')</h6>
                            </div>
                        </div>
                    </div>
                @endforelse
            </div>
            @if ($generatedWebsites->hasPages())
                <div class="pagination-wrapper">
                    {{ paginateLinks($generatedWebsites) }}
                </div>
            @endif
        </div>
    </section>
@endsection
