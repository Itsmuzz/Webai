@php
    $blogContent = getContent('blog.content', true);
    $blogElement = getContent('blog.element', null, 3, false);
@endphp

<section class="blog my-120">
    <div class="container">
        <div class="section-heading">
            <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                <span class="text--gradient">{{ __($blogContent?->data_values?->heading ?? '') }}</span>
            </div>
            <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                {{ __($blogContent?->data_values?->subheading ?? '') }}
            </h2>
            <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($blogContent?->data_values?->short_details ?? '') }}
            </p>
        </div>
        <div class="row justify-content-center gy-4">
            @include('Template::partials.blogs', ['blogs' => $blogElement])
        </div>
    </div>
</section>
