@php
    $featureContent = getContent('feature.content', true);
    $featureElement = getContent('feature.element', orderById: true);
@endphp
<section class="core-feature my-120">
    <div class="container">
        <div class="section-heading">
            <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                <span class="text--gradient"> {{ __($featureContent?->data_values?->heading ?? '') }}</span>
            </div>
            <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                {{ __($featureContent?->data_values?->subheading ?? '') }}
            </h2>
            <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($featureContent?->data_values?->short_description ?? '') }}
            </p>
        </div>

        <div class="core-feature-layout">
            @foreach ($featureElement as $feature)
                <div class="core-feature-card" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                    <div class="core-feature-card__content">
                        <span class="core-feature-card__tagline">
                            {{ __($feature?->data_values?->title ?? '') }}
                        </span>
                        <h3 class="core-feature-card__title">
                            {{ __($feature?->data_values?->subtitle ?? '') }}
                        </h3>
                        <p class="core-feature-card__desc">
                            {{ __($feature?->data_values?->short_details ?? '') }}
                        </p>
                    </div>
                    <img class="core-feature-card__thumb" src="{{ frontendImage('feature', $feature?->data_values?->image ?? '', '550x360') }}" alt="img">
                </div>
            @endforeach
        </div>
    </div>
</section>
