@php
    $testimonialContent = getContent('testimonial.content', true);
    $testimonialElement = getContent('testimonial.element', orderById: true);
@endphp

<section class="testimonial my-120">
    <div class="container-fluid">
        <div class="section-heading">
            <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                <span class="text--gradient">{{ __($testimonialContent?->data_values?->heading ?? '') }}</span>
            </div>
            <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                {{ __($testimonialContent?->data_values?->subheading ?? '') }}
            </h2>
            <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($testimonialContent?->data_values?->short_description ?? '') }}
            </p>
        </div>
        <div class="testimonial-slider" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="400">
            @foreach ($testimonialElement as $testimonial)
                <div class="testimonial-slider__slide">
                    <div class="testimonial-card">
                        <div class="testimonial-card__header">
                            <div class="rating-list">
                                @php
                                    echo showRatings($testimonial?->data_values?->rating ?? 5);
                                @endphp
                            </div>
                        </div>
                        <div class="testimonial-card__body">
                            <h6 class="testimonial-card__title">
                                {{ __($testimonial?->data_values?->review ?? '') }}
                            </h6>
                        </div>
                        <div class="testimonial-card__footer">
                            <div class="testimonial-card-user">
                                <img class="testimonial-card-user__thumb" src="{{ frontendImage('testimonial', $testimonial?->data_values?->image ?? '', '60x60') }}" alt="">
                                <div class="testimonial-card-user__content">
                                    <p class="testimonial-card-user__name">{{ __($testimonial?->data_values?->name ?? '') }}</p>
                                    <span class="testimonial-card-user__position">{{ __($testimonial?->data_values?->designation ?? '') }}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
    <div class="testimonial-slider-ctrl" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300"></div>
</section>
