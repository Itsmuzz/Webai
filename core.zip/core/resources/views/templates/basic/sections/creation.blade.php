@php
    $creationContent = getContent('creation.content', true);
    $creationElement = getContent('creation.element', orderById: true);
@endphp
<section class="featuren-project my-120">
    <div class="container">
        <div class="section-heading">
            <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                <span class="text--gradient"> {{ __($creationContent?->data_values?->heading ?? '') }}</span>
            </div>
            <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                {{ __($creationContent?->data_values?->subheading ?? '') }}
            </h2>
            <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($creationContent?->data_values?->short_description ?? '') }}
            </p>
        </div>
        <div class="row gy-4">
            @php
                $count = 400;
            @endphp
            @foreach ($creationElement as $creation)
                <div class="col-xsm-6 col-sm-6 col-lg-4" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="{{ $count }}">
                    <div class="project-card">
                        <div class="project-card__header">
                            <h6 class="project-card__title">
                                <a href="javascript:void(0)">{{ __($creation?->data_values?->title ?? '') }}</a>
                            </h6>
                        </div>
                        <div class="project-card__body">
                            <div class="project-card__thumb">
                                <img src="{{ frontendImage('creation', $creation?->data_values?->image ?? '', '385x215') }}" alt="img">
                            </div>

                        </div>
                        <div class="project-card__footer">
                            <div class="project-card-user">
                                <img class="project-card-user__thumb" src="{{ frontendImage('creation', $creation?->data_values?->user_image ?? '', '100x100') }}" alt="img">
                                <div class="project-card-user__content">
                                    <p class="project-card-user__name">{{ __($creation?->data_values?->fullname ?? '') }}</p>
                                    <ul class="project-card-meta">
                                        <li class="project-card-meta__item">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                 stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"
                                                 class="lucide lucide-timer-icon lucide-timer">
                                                <line x1="10" x2="14" y1="2" y2="2" />
                                                <line x1="12" x2="15" y1="14" y2="11" />
                                                <circle cx="12" cy="14" r="8" />
                                            </svg>
                                            {{ __($creation?->data_values?->created_at ?? '') }}
                                        </li>
                                    </ul>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            @endforeach
        </div>
        <div class="mt-60 text-center" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="1000">
            <a class="btn btn-outline--base" href="{{ url($creationContent?->data_values?->button_url ?? '#') }}">
                {{ __($creationContent?->data_values?->button_name ?? '') }}
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                     stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                     class="lucide lucide-square-arrow-up-right-icon lucide-square-arrow-up-right">
                    <rect width="18" height="18" x="3" y="3" rx="2" />
                    <path d="M8 8h8v8" />
                    <path d="m8 16 8-8" />
                </svg>
            </a>
        </div>
    </div>
</section>
