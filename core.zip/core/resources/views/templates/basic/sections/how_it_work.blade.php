@php
    $howItWorkContent = getContent('how_it_work.content', true);
    $howItWorkElement = getContent('how_it_work.element', false, 3, true);
@endphp

<section class="htw my-120">
    <div class="container">
        <div class="row gy-4 align-items-center">
            <div class="col-lg-7">
                <div class="section-heading style-left">
                    <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                        <span class="text--gradient"> {{ __($howItWorkContent?->data_values?->heading ?? '') }}</span>
                    </div>
                    <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                        {{ __($howItWorkContent?->data_values?->subheading ?? '') }}
                    </h2>
                    <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                        {{ __($howItWorkContent?->data_values?->short_description ?? '') }}
                    </p>

                    <div data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                        <a class="btn btn-outline--base" href="{{ url($howItWorkContent?->data_values?->button_url ?? '') }}">
                            {{ __($howItWorkContent?->data_values?->button_name ?? '') }}
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round"
                                 class="lucide lucide-square-arrow-up-right-icon lucide-square-arrow-up-right">
                                <rect width="18" height="18" x="3" y="3" rx="2"></rect>
                                <path d="M8 8h8v8"></path>
                                <path d="m8 16 8-8"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 d-none d-lg-block">
                <div data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                    <img class="htw-thumb" src="{{ frontendImage('how_it_work', $howItWorkContent?->data_values?->image ?? '', '500x335') }}" alt="img">
                </div>
            </div>
        </div>
        <ul class="htw-step mt-60" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="400">
            @foreach ($howItWorkElement as $howItWorkItem)
                <li class="htw-step-item">
                    <div class="htw-step-item__header">
                        <div class="htw-step-item__icon">
                            <img src="{{ frontendImage('how_it_work', $howItWorkItem?->data_values?->image ?? '', '60x60') }}" alt="img">
                        </div>
                    </div>
                    <div class="htw-step-item__body">
                        <h6 class="htw-step-item__title">
                            {{ __($howItWorkItem?->data_values?->title ?? '') }}
                        </h6>
                        <p class="htw-step-item__desc">
                            {{ __($howItWorkItem?->data_values?->short_details ?? '') }}
                        </p>
                    </div>
                    <div class="htw-step-item__footer">
                        <a class="htw-step-item__link" href="{{ url($howItWorkItem?->data_values?->button_url ?? '#') }}">
                            {{ __($howItWorkItem?->data_values?->button_name ?? '') }}
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                                 stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                 class="lucide lucide-move-right-icon lucide-move-right">
                                <path d="M18 8L22 12L18 16"></path>
                                <path d="M2 12H22"></path>
                            </svg>
                        </a>
                    </div>
                </li>
            @endforeach
        </ul>
    </div>
</section>
