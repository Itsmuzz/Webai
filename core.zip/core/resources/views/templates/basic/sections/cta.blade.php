@php
    $ctaContent = getContent('cta.content', true);
@endphp
<section class="cta my-120">
    <div class="container">
        <div class="cta-card">
            <div class="cta-card__shape one"></div>
            <div class="cta-card__shape two"></div>
            <div class=" section-heading">
                <div class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                    <span class="text-white">{{ __($ctaContent?->data_values?->heading ?? '') }}</span>
                </div>
                <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                    {{ __($ctaContent?->data_values?->subheading ?? '') }}
                </h2>
                <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                    {{ __($ctaContent?->data_values?->short_details ?? '') }}
                </p>
                <div class="mt-4 mt-sm-5" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="500">
                    <a class="btn btn--lg btn--dark" href="{{ url($ctaContent?->data_values?->button_url ?? '#') }}">
                        {{ __($ctaContent?->data_values?->button_name ?? '') }}
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
