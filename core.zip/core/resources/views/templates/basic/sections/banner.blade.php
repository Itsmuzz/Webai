@php
    $bannerContent = getContent('banner.content', true);
    $bannerElement = getContent('banner.element', orderById: true);
@endphp
<section class="banner">
    <div class="banner-bg">
        <div class="banner-bg__shape one"></div>
        <div class="banner-bg__shape two"></div>
        <div class="banner-bg__shape three"></div>
        <img class="banner-bg__pattern" src="{{ asset(activeTemplate(true) . 'images/thumbs/banner/pattern.png') }}" alt="img">
    </div>
    <div class="container">
        <div class="banner-content">
            <span class="banner-content__tagline" data-aos="zoom-in-down" data-aos-duration="1500" data-aos-delay="100">
                {{ __($bannerContent?->data_values?->heading ?? '') }}
            </span>
            <h1 class="banner-content__title" data-aos="zoom-in-down" data-aos-duration="1500" data-aos-delay="200">
                {{ __($bannerContent?->data_values?->subheading ?? '') }}
            </h1>
            <p class="banner-content__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($bannerContent?->data_values?->short_description ?? '') }}
            </p>
            <div class="banner-content__btns" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="400">
                <a class="btn btn--lg btn--white" href="{{ url($bannerContent?->data_values?->button_one_url ?? '#') }}">
                    {{ __($bannerContent?->data_values?->button_one_name ?? '') }}
                </a>
                <a class="btn btn--lg btn-outline--white" href="{{ url($bannerContent?->data_values?->button_two_url ?? '#') }}">
                    {{ __($bannerContent?->data_values?->button_two_name ?? '') }}
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                         stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                         class="lucide lucide-move-right-icon lucide-move-right">
                        <path d="M18 8L22 12L18 16" />
                        <path d="M2 12H22" />
                    </svg>
                </a>
            </div>
        </div>
    </div>
    <div class="banner-slider" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="500">
        @foreach ($bannerElement as $banner)
            <div class="banner-slider__slide">
                <div class="banner-slider__item">
                    <img src="{{ frontendImage('banner', $banner?->data_values?->image ?? '', '20x20') }}" alt="img">
                    {{ __($banner?->data_values?->title ?? '') }}
                </div>
            </div>
        @endforeach
    </div>


    @include('Template::partials.website_form')
</section>


@push('script')
    <script>
        (function($) {
            "use strict";


            $("#gen-form").on("submit", function(e) {
                e.preventDefault();

                let form = $(this);
                let auth = Number(`{{ auth()->id() ?? 0 }}`);
                if (!auth) {
                    notify('error', 'Please log in to your account');
                    return;
                }

                let pagesId = [];
                let pagesData = {};
                $('input[name="website_page_id[]"]:checked').each(function() {
                    let pageId = $(this).val();
                    pagesId.push(pageId);
                    let sections = $('select[name="pages[' + pageId + '][]"]').val();
                    if (sections && sections.length > 0) {
                        pagesData[pageId] = sections;
                    }
                });


                let websiteTypeId = $('select[name="website_type_id"]').val();
                let fontFamily = $('select[name="font_family"]').val();

                let data = {
                    _token: "{{ csrf_token() }}",
                    website_type_id: websiteTypeId,
                    font_family: fontFamily,
                    website_page_id: pagesId,
                    pages: pagesData,
                    color: $('input[name="color"]').val(),
                }

                $.ajax({
                    type: "POST",
                    url: "{{ route('user.website.generate') }}",
                    data: data,
                    beforeSend: function() {
                        $(form).find('.generateBtn').addClass('processing').prop('disabled', true);
                        $(form).find(".gen-form-loader").removeClass('d-none');
                        $(form).find('.gen-form-empty').addClass('d-none');
                        $(form).find('.gen-form-card').addClass('d-none');
                    },
                    success: function(response) {
                        $(form).find(".gen-form-loader").addClass('d-none');

                        if (response.status === 'error') {
                            $(form).find('.generateBtn').removeClass('processing').prop('disabled', false);

                            $(form).find('.gen-form-card__body').each(function() {
                                $(this).find('.form-group').addClass('d-none');
                            });

                            $(form).find(".gen-form-card").removeClass('d-none');
                            $(form).find(".gen-form-empty").removeClass('d-none');

                            $('input[name="website_page_id[]"]').prop('checked', false);
                            $('select[name^="pages["]').val(null).trigger('change');
                            notify('error', response.message.error);
                            return;
                        }

                        $(form).find(".gen-form-result").removeClass('d-none');
                        $(form).find(".gen-form-result").html(response.data.html);
                    }
                });
            });


            let currentIndex = -1;
            $("[name=search]").on("keydown", function(e) {
                let parent = $(this).closest('.gen-form-search');
                let items = parent.siblings('.page-list-data').find('.custom-check__label');
                let total = items.length;

                if (total === 0) return;

                if (e.key === "ArrowDown") {
                    e.preventDefault();
                    currentIndex = (currentIndex + 1) % total;
                } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    currentIndex = (currentIndex - 1 + total) % total;
                } else if (e.key === "Enter") {
                    e.preventDefault();
                    if (currentIndex >= 0) {
                        items.eq(currentIndex).trigger("click");
                    }
                } else {
                    return;
                }

                items.removeClass("active-item");
                if (currentIndex >= 0) {
                    items.eq(currentIndex).addClass("active-item");
                }
            });


            $("[name=search]").on("input", function(e) {
                e.preventDefault();
                let searchValue = $(this).val().toLowerCase().trim();
                currentIndex = -1;

                let parent = $(this).closest('.gen-form-search');
                let listItems = parent.siblings('.page-list-data').find('.custom-check__label');

                listItems.each(function() {
                    let text = $(this).text().toLowerCase();
                    if (text.includes(searchValue)) {
                        $(this).closest('.single-page-item').show();
                    } else {
                        $(this).closest('.single-page-item').hide();
                    }
                });
            });

        })(jQuery)
    </script>
@endpush
