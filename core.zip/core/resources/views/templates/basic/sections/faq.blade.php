@php
    $faqContent = getContent('faq.content', true);
    $faqElement = getContent('faq.element', orderById: true);
    $socialIcons = getContent('social_icon.element', orderById: true);
@endphp
<section class="faq my-120">
    <div class="container">
        <div class="section-heading">
            <span class="section-heading__tagline" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="100">
                {{ __($faqContent?->data_values?->heading ?? '') }}
            </span>
            <h2 class="section-heading__title" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="200">
                {{ __($faqContent?->data_values?->subheading ?? '') }}
            </h2>
            <p class="section-heading__desc" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="300">
                {{ __($faqContent?->data_values?->short_details ?? '') }}
            </p>
        </div>
        <div class="row gy-4">
            <div class="col-lg-6 col-xl-7">
                <div id="faq-accordion" class="accordion custom--accordion">
                    @foreach ($faqElement as $key => $faq)
                        <div class="accordion-item" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="0">
                            <h2 class="accordion-header">
                                <button class="accordion-button {{ $loop->first ? '' : 'collapsed' }}" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#faq-accordion-item-{{ $key }}" @if ($loop->first) aria-expanded="true" @else aria-expanded="false" @endif
                                        aria-controls="faq-accordion-item-{{ $key }}">
                                    <span class="text"> {{ __($faq?->data_values?->question ?? '') }}</span>
                                </button>
                            </h2>
                            <div id="faq-accordion-item-{{ $key }}" class="accordion-collapse collapse {{ $loop->first ? 'show' : '' }}"
                                 data-bs-parent="#faq-accordion">
                                <div class="accordion-body">
                                    <p class="accordion-text">
                                        {{ __($faq?->data_values?->answer ?? '') }}
                                    </p>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
            <div class="col-lg-6 col-xl-5">
                <div class="faq-content" data-aos="fade-up" data-aos-duration="1500" data-aos-delay="400">
                    <h6 class="faq-content__title">
                        {{ __($faqContent?->data_values?->title ?? '') }}
                    </h6>
                    <p class="faq-content__desc">
                        {{ __($faqContent?->data_values?->subtitle ?? '') }}
                    </p>
                    <div class="faq-content__block">
                        <span class="title">@lang('Find Us')</span>
                        <ul class="social-list">
                            @foreach ($socialIcons as $social)
                                <li class="social-list__item">
                                    <a href="{{ $social?->data_values?->url ?? '' }}" class="social-list__link" target="_blank">
                                        @php
                                            echo $social?->data_values?->social_icon ?? '';
                                        @endphp
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="faq-content__block">
                        <span class="title">@lang('Or')</span>
                        <a class="btn btn--sm btn-outline--base" href="{{ url($faqContent?->data_values?->button_url ?? '') }}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                                 fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                 stroke-linejoin="round" class="lucide lucide-headset-icon lucide-headset">
                                <path
                                      d="M3 11h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-5Zm0 0a9 9 0 1 1 18 0m0 0v5a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3Z" />
                                <path d="M21 16v2a4 4 0 0 1-4 4h-5" />
                            </svg>
                            {{ __($faqContent?->data_values?->button_name ?? '') }}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
