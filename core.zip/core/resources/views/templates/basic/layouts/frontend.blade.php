@extends('Template::layouts.app')
@section('app')
    @yield('content')
@endsection
