@props(['className' => '', 'submitBtn' => 'btn btn--primary', 'closeBtn' => 'btn btn--dark', 'btnClose' => 'close'])

<div id="confirmationModal" class="modal fade  {{ $className }}" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">@lang('Confirmation Alert!')</h5>
                <button type="button" class="{{ $btnClose }}" data-bs-dismiss="modal" aria-label="Close">
                    @if ($btnClose == 'close')
                        <i class="las la-times"></i>
                    @endif
                </button>
            </div>
            <form method="POST">
                @csrf
                <div class="modal-body">
                    <p class="question"></p>
                    {{ $slot }}
                </div>
                <div class="modal-footer">
                    <button type="button" class="{{ $closeBtn }}" data-bs-dismiss="modal">@lang('No')</button>
                    <button type="submit" class="{{ $submitBtn }}">@lang('Yes')</button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('script')
    <script>
        (function($) {
            "use strict";
            $(document).on('click', '.confirmationBtn', function() {
                var modal = $('#confirmationModal');
                let data = $(this).data();
                modal.find('.question').text(`${data.question}`);
                modal.find('form').attr('action', `${data.action}`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
@endpush
