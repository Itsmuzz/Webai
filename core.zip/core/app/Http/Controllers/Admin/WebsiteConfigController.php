<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WebsitePage;
use App\Models\WebsiteSection;
use App\Models\WebsiteType;
use Illuminate\Http\Request;

class WebsiteConfigController extends Controller {
    public function typeIndex() {
        $pageTitle    = 'Website Types';
        $websiteTypes = WebsiteType::searchable(['name'])->orderBy('name', 'asc')->paginate(getPaginate());
        return view("admin.website_config.types", compact('pageTitle', 'websiteTypes'));
    }

    public function typeStore(Request $request, $id = 0) {
        $request->validate([
            'name' => "required|max:40|unique:website_types,name," . $id,
        ]);

        if ($id) {
            $websiteType  = WebsiteType::findOrFail($id);
            $notification = "Website type updated successfully";
        } else {
            $websiteType  = new WebsiteType();
            $notification = "Website type added successfully";
        }

        $websiteType->name = $request->name;
        $websiteType->save();

        $notify[] = ['success', $notification];
        return back()->withNotify($notify);
    }

    public function typeStatus($id) {
        return WebsiteType::changeStatus($id);
    }

    public function pageIndex() {
        $pageTitle    = 'Website Pages';
        $websitePages = WebsitePage::searchable(['name'])->orderBy('name', 'asc')->paginate(getPaginate());
        return view("admin.website_config.pages", compact('pageTitle', 'websitePages'));
    }

    public function pageStore(Request $request, $id = 0) {
        $request->validate([
            'name' => "required|max:40|unique:website_pages,name," . $id,
        ]);

        if ($id) {
            $websitePage  = WebsitePage::findOrFail($id);
            $notification = "Website page updated successfully";
        } else {
            $websitePage  = new WebsitePage();
            $notification = "Website page added successfully";
        }

        $websitePage->name = $request->name;
        $websitePage->save();

        $notify[] = ['success', $notification];
        return back()->withNotify($notify);
    }

    public function pageStatus($id) {
        return WebsitePage::changeStatus($id);
    }

    public function sectionIndex() {
        $pageTitle = 'Website Sections';
        $sections  = WebsiteSection::searchable(['name'])->orderBy('name', 'asc')->paginate(getPaginate());
        return view("admin.website_config.sections", compact('pageTitle', 'sections'));
    }

    public function sectionStore(Request $request, $id = 0) {
        $request->validate([
            'name' => "required|max:40|unique:website_sections,name," . $id,
        ]);

        if ($id) {
            $websiteSection = WebsiteSection::findOrFail($id);
            $notification   = "Website section updated successfully";
        } else {
            $websiteSection = new WebsiteSection();
            $notification   = "Website section added successfully";
        }

        $websiteSection->name = $request->name;
        $websiteSection->save();

        $notify[] = ['success', $notification];
        return back()->withNotify($notify);
    }

    public function sectionStatus($id) {
        return WebsiteSection::changeStatus($id);
    }
}
