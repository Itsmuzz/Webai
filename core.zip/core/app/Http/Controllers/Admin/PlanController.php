<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use Illuminate\Http\Request;

class PlanController extends Controller {
    public function index() {
        $pageTitle = 'Pricing Plan';
        $plans     = Plan::searchable(['name'])->orderBy('id', 'desc')->paginate(getPaginate());
        return view('admin.plan.index', compact('pageTitle', 'plans'));
    }

    public function add($id = 0) {
        if ($id) {
            $pageTitle = 'Update Plan';
            $plan      = Plan::findOrFail($id);
        } else {
            $pageTitle = 'Add Plan';
            $plan      = null;
        }
        return view('admin.plan.add', compact('pageTitle', 'plan'));
    }

    public function store(Request $request, $id = 0) {
        $request->validate([
            'name'              => 'required|string|max:40|unique:plans,name,' . $id,
            'monthly_price'     => 'required|numeric|gt:0',
            'yearly_price'      => 'required|numeric|gt:0',
            'monthly_limit'     => 'required|integer|gt:0',
            'yearly_limit'      => 'required|integer|gt:0',
            'max_page'          => 'required|integer|gt:0',
            'max_sections'      => 'required|integer|gt:0',
            'short_description' => 'required|string|max:255',
        ]);

        if ($id) {
            $plan         = Plan::findOrFail($id);
            $notification = 'Plan updated successfully';
        } else {
            $plan         = new Plan();
            $notification = 'Plan added successfully';
        }

        $plan->name              = $request->name;
        $plan->monthly_price     = $request->monthly_price;
        $plan->yearly_price      = $request->yearly_price;
        $plan->monthly_limit     = $request->monthly_limit;
        $plan->yearly_limit      = $request->yearly_limit;
        $plan->short_description = $request->short_description;
        $plan->max_page          = $request->max_page;
        $plan->max_sections      = $request->max_sections;
        $plan->save();

        $notify[] = ['success', $notification];
        return back()->withNotify($notify);
    }
    public function status($id) {
        return Plan::changeStatus($id);
    }
}
