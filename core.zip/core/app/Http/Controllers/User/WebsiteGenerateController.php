<?php

namespace App\Http\Controllers\User;

use App\Constants\Status;
use App\Http\Controllers\Controller;
use App\Models\GenerateWebsite;
use App\Models\Subscription;
use App\Models\WebsiteInformation;
use App\Models\WebsitePage;
use App\Models\WebsiteSection;
use App\Models\WebsiteType;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;
use ZipArchive;

class WebsiteGenerateController extends Controller {
    public function history() {
        $pageTitle         = 'Generated Website History';
        $user              = auth()->user();
        $generatedWebsites = GenerateWebsite::where('user_id', $user->id)->with('websiteType')->orderBy('id', 'desc')->paginate(getPaginate());
        return view('Template::user.website.history', compact('generatedWebsites', 'pageTitle', 'user'));
    }

    public function generate(Request $request) {
        $validated = $this->validateUserAndPrompt($request);
        if (isset($validated['error'])) {
            return responseError($validated['error'], $validated['message']);
        }

        $user        = $validated['user'];
        $websiteType = $validated['websiteType'];

        $apiToken = gs('gemini_api_key');
        if (!$apiToken) {
            return responseError('missing_api_token', 'API key is missing for the selected engine.');
        }

        $subscription = Subscription::where('user_id', auth()->id())->where('expired_date', '>', now())->where('status', Status::ENABLE)->orderBy('id', 'desc')->first();
        if (!$subscription) {
            return responseError('subscription_error', 'Subscription is required to fetching job listings.');
        }

        $randomFolder = 'website_' . uniqid() . '_' . time();
        $basePath     = getFilePath('websites') . '/' . $randomFolder;

        if (!file_exists($basePath)) {
            mkdir($basePath, 0755, true);
        }

        $user->website_limit -= 1;
        $user->save();

        $generateWebsite                  = new GenerateWebsite();
        $generateWebsite->user_id         = $user->id;
        $generateWebsite->folder_name     = $randomFolder;
        $generateWebsite->website_type_id = $websiteType->id;
        $generateWebsite->color           = $request->color;
        $generateWebsite->total_page      = count($request->pages);
        $generateWebsite->page_remain     = count($request->pages);
        $generateWebsite->font_family     = $request->font_family;
        $generateWebsite->save();

        foreach ($request->pages as $pageId => $sectionIds) {
            $page = WebsitePage::active()->find($pageId);
            if (!$page) {
                continue;
            }

            $filename = slug($page->name) . '.html';
            $sections = WebsiteSection::active()->whereIn('id', $sectionIds)->pluck('name')->toArray();

            $pageDetails = [
                'name'     => $page->name,
                'filename' => $filename,
                'sections' => $sections,
            ];

            $websiteInformation                      = new WebsiteInformation();
            $websiteInformation->generate_website_id = $generateWebsite->id;
            $websiteInformation->website_page_id     = $page->id;
            $websiteInformation->section_ids         = $sectionIds;
            $websiteInformation->details             = $pageDetails;
            $websiteInformation->save();
        }

        $html = view('Template::user.website.preview')->render();
        $data = [
            'html' => $html,
        ];
        return responseSuccess('success', 'Website generated successfully', $data);

    }

    private function validateUserAndPrompt($request) {

        $user  = auth()->user();
        $rules = [
            'website_type_id'   => 'required|integer|exists:website_types,id',
            'font_family'       => 'required|string|max:255',
            'color'             => [
                'required',
                'string',
                'regex:/^#[A-Fa-f0-9]{6}$/',
            ],
            'website_page_id'   => 'required|array|min:1',
            'website_page_id.*' => 'required|integer|exists:website_pages,id',
            'pages'             => 'required|array|min:1',
            'pages.*'           => 'required|array|min:1',
            'pages.*.*'         => 'required|integer|exists:website_sections,id',
        ];

        $messages = [
            'pages.required'     => 'Please select at least one page.',
            'pages.array'        => 'Invalid format for pages.',
            'pages.*.required'   => 'Each selected page must include at least one section.',
            'pages.*.array'      => 'Sections must be provided as a list.',
            'pages.*.*.required' => 'A section is required.',
            'pages.*.*.integer'  => 'Each section ID must be a valid number.',
            'pages.*.*.exists'   => 'One or more selected sections are invalid.',
        ];

        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return ['error' => 'validation_error', 'message' => $validator->errors()->all()];
        }

        if (!$user->plan_id) {
            return ['error' => 'no_plan', 'message' => 'You do not have any active subscription plan.'];
        }

        if ($user->website_limit <= 0) {
            return ['error' => 'insufficient_credit', 'message' => 'You do not have enough credit to perform this action.'];
        }

        if ($user->expired_date < now()) {
            return ['error' => 'plan_expired', 'message' => 'Your subscription plan has expired. Please renew to continue using the service.'];
        }

        if (!in_array($request->font_family, fontFamilyList())) {
            return ['error' => 'plan_expired', 'message' => 'Invalid font family.'];
        }

        $websiteType = WebsiteType::active()->where('id', $request->website_type_id)->first();
        if (!$websiteType) {
            return ['status' => 'error', 'message' => 'Invalid website type.'];
        }

        $websitePages = $request->pages;
        if (count($websitePages) > $user->max_page) {
            return ['error' => 'page_limit_exceeded', 'message' => 'You have exceeded your page limit.'];
        }

        $sectionIds = [];
        foreach ($websitePages as $sectionIds) {
            if (count($sectionIds) > $user->max_sections) {
                return ['error' => 'section_limit_exceeded', 'message' => 'You have exceeded your section limit.'];
            }
        }

        return compact('user', 'websiteType');
    }

    public function download($id) {

        $id = decrypt($id);

        $generateWebsite = GenerateWebsite::where('user_id', auth()->id())->where('id', $id)->first();

        $zipFileName = 'website_' . $generateWebsite->id . '.zip';
        $zipPath     = storage_path('app/' . $zipFileName);
        $zip         = new ZipArchive;
        if ($zip->open($zipPath, ZipArchive::CREATE) === TRUE) {
            $files = File::files(getFilePath('websites') . '/' . $generateWebsite->folder_name);
            foreach ($files as $file) {
                $zip->addFile($file->getRealPath(), $file->getFilename());
            }
            $zip->close();
        } else {
            return response()->json(['error' => 'Failed to create ZIP.']);
        }
        return response()->download($zipPath)->deleteFileAfterSend(true);

    }

    public function preview($slug, $path = null) {
        $generateWebsite = GenerateWebsite::where('user_id', auth()->id())->where('folder_name', $slug)->first();
        $basePath        = getFilePath('websites') . '/' . $generateWebsite->folder_name;

        $files = File::files(getFilePath('websites') . '/' . $generateWebsite->folder_name);

        $previewFile = '';
        foreach ($files as $key => $file) {
            $filename = basename($file);
            if ($filename == 'index.html' || $filename == 'home.html') {
                $previewFile = $filename;
                break;
            }
        }

        if (!$previewFile) {
            $previewFile = $files[0]->getFilename();
        }

        $fullPath = $basePath . '/' . $previewFile;
        if (!File::exists($fullPath)) {
            abort(404);
        }
        return redirect()->to(asset($fullPath));
    }

}