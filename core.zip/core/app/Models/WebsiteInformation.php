<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WebsiteInformation extends Model {

    protected $casts = [
        'section_ids' => 'array',
        'details'     => 'object',
    ];
}
