<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GenerateWebsite extends Model {
    public function user() {
        return $this->belongsTo(User::class);
    }

    public function websiteInformation() {
        return $this->hasMany(WebsiteInformation::class);
    }

    public function websiteType() {
        return $this->belongsTo(WebsiteType::class);
    }
}
