<?php

return [
    // 'home'=>'contact'
    'pricing' => false,
];
